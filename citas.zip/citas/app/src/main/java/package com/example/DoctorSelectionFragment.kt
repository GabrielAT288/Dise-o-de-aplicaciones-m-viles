package com.example.citas
import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.citas.Doctor
import com.example.citas.DoctorAdapter
import com.example.citas.SharedViewModel

class DoctorSelectionFragment : Fragment() {

    private lateinit var viewModel: SharedViewModel

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_confirmation, container, false)


        viewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)


        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView_doctors)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = DoctorAdapter(getDoctors(), onDoctorSelected)

        return view
    }


    private fun getDoctors(): List<Doctor> {
        return listOf(
            Doctor("Dr. John Doe", "Cardiología", "Disponible"),
            Doctor("Dra. Jane Smith", "Dermatología", "Disponible"),

            )
    }


    private val onDoctorSelected: (Doctor) -> Unit = { doctor ->
        viewModel.selectedDoctor.value = doctor


        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, AppointmentDetailsFragment())
            .addToBackStack(null)
            .commit()
    }
}