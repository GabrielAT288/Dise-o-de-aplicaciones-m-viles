package com.example.citas

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SharedViewModel : ViewModel() {
    val selectedDoctor = MutableLiveData<Doctor>()
    val appointmentDate = MutableLiveData<String>()
    val appointmentTime = MutableLiveData<String>()
}