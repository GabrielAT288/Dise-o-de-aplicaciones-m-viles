package com.example.citas

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import android.widget.TimePicker
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.citas.ConfirmationFragment
import com.example.citas.SharedViewModel

class AppointmentDetailsFragment : Fragment() {

    private lateinit var viewModel: SharedViewModel
    private lateinit var datePicker: DatePicker
    private lateinit var timePicker: TimePicker

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_appointment_details, container, false)

        viewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

        val doctorNameTextView = view.findViewById<TextView>(R.id.textView_doctor_name)
        val doctorSpecialtyTextView = view.findViewById<TextView>(R.id.textView_doctor_specialty)
        val selectedDoctor = viewModel.selectedDoctor.value
        doctorNameTextView.text = selectedDoctor?.name
        doctorSpecialtyTextView.text = selectedDoctor?.specialty

        datePicker = view.findViewById(R.id.datePicker)
        timePicker = view.findViewById(R.id.timePicker)

        val nextButton = view.findViewById<Button>(R.id.button_next)
        nextButton.setOnClickListener {
            val date = "${datePicker.dayOfMonth}/${datePicker.month + 1}/${datePicker.year}"
            val time = "${timePicker.hour}:${timePicker.minute}"

            viewModel.appointmentDate.value = date
            viewModel.appointmentTime.value = time

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container_view, ConfirmationFragment())
                .addToBackStack(null)
                .commit()
        }

        return view
    } // Aquí cierra el método onCreateView

} // Y aquí cierra la clase AppointmentDetailsFragment
