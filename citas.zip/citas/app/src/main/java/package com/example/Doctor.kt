
package com.example.citas

data class Doctor(
    val name: String,
    val specialty: String,
    val availability: String
)